recommended platforms: ***any linux distro (preffered -> Fedora, Ubuntu)***

***prerequisite :***
1. ```golang``` with path as global
2. ```node version >= 7.0.0``` & corresponding ```npm```
3. ```python version >= 2.5 and < 3.0```



*copy the following instructions in your terminal :*

1. clone this repository in your local environment.
2. ```cd Jarvis-Desktop/shell/```.
3. execute ```./start-service.sh```
4. ``` cd .. ```
5. ``` npm test ``` *// for testing*
6. ``` npm start ``` *// locally execute jarvis-desktop*
